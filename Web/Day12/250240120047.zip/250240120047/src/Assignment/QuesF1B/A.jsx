import B from "./B";
import C from "./C";

export default function A(){
    return(
        <div>
            This is A component
            <B/>
            <C/>
        </div>
    )
}