export default function B(){
    return(
        <div>
            This is B component
        </div>
    )
}