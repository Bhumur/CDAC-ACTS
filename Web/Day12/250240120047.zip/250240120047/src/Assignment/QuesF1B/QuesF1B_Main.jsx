import A from "./A";

export default function QuesF1B_Main(){
    return (
        <>
            <A/>
        </>
    )
}