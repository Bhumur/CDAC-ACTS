import B from "./B";

export default function A(){
    return(
        <div>
            This is A component
            <B/>
        </div>
    )
}