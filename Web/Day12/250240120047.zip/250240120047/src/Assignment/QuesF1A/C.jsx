export default function C(){
    return(
        <div>
            This is C component
        </div>
    )
}