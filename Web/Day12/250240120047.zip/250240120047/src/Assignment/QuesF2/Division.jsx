export default function Division(x){
    return (
        <div>
            Division : {x.nums[0] / x.nums[1]} 
        </div>
    )
}