// import QuesF1A_Main from "./Assignment/QuesF1A/QuesF1A_Main";
// import QuesF1B_Main from "./Assignment/QuesF1B/QuesF1B_Main";
// import QuesF1C_Main from "./Assignment/QuesF1C/QuesF1C_Main";
// import QuesF1D_Main from "./Assignment/QuesF1D/QuesF1D_Main";
// import QuesF2_Main from "./Assignment/QuesF2/QuesF2_Main";
// import QuesF3_Main from "./Assignment/QuesF3/QuesF3_Main";
import QuesF4_Main from "./Assignment/QuesF4/QuesF4_Main";

function App() {
  return (
    <>
      {/* <QuesF1A_Main/>  */}
      {/* <QuesF1B_Main/> */}
      {/* <QuesF1C_Main/> */}
      {/* <QuesF1D_Main/> */}
      {/* <QuesF2_Main/> */}
      {/* <QuesF3_Main /> */}
      <QuesF4_Main/>
    </>
  );
}

export default App;
