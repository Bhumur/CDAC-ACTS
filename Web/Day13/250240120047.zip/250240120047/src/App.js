// import QuesA1_Main from './Assignment/QuesA1/QuesA1_Main';
// import QuesA2_Main from "./Assignment/QuesA2/QuesA2_Main";
// import QuesB1_Main from "./Assignment/QuesB1/QuesB1_Main";

import QuesB2_Main from "./Assignment/QuesB2/QuesA2_Main";

function App() {
  return (
    <div className="App">
      {/* <QuesA1_Main/> */}
      {/* <QuesA2_Main/> */}
      {/* <QuesB1_Main/> */}
      <QuesB2_Main/>
    </div>
  );
}

export default App;
