import { createContext } from "react";
const FruitContext = createContext();
export default FruitContext;

