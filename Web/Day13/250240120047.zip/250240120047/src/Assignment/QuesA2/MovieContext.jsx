import { createContext } from "react";
const MovieContext  = createContext();
export default MovieContext