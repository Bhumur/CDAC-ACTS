package com.cdac.acts.exception;

@SuppressWarnings("serial")
public class MinBalanceException extends Exception{
	public MinBalanceException(String msg) {
		super(msg);
	}
	
}