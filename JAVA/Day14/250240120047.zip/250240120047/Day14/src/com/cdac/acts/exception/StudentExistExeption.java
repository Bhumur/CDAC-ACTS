package com.cdac.acts.exception;
@SuppressWarnings("serial")
public class StudentExistExeption extends Exception{

	public StudentExistExeption(String str) {
		super(str);
	}
}
