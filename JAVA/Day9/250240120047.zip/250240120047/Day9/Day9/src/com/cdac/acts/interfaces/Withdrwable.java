package com.cdac.acts.interfaces;

public interface Withdrwable {
	double withdraw(double a);
}
