package com.cdac.acts.interfaces;

public interface Depositable {
	double depoist(double a);

}
