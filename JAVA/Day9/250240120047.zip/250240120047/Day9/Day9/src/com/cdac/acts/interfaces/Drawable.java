package com.cdac.acts.interfaces;

public interface Drawable {
	 void draw();
	 double perimeter();
	 double area();
}
