package com.cdac.acts.interfaces;

public interface Muturable {
	double intrest1 = 7.0;
	double intrest2 = 7.5;
	double intrest3 = 7.9;
	double intrest4 = 8.2;
	double intrest5 = 8.5;
	
	double calculateMatutyAmount();
}
