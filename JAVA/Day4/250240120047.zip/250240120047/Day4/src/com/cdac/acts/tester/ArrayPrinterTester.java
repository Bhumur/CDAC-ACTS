package com.cdac.acts.tester;
import com.cdac.acts.array.ArrayPrinter;
public class ArrayPrinterTester {

	public static void main(String[] args) {
		
		
		int num[] = {1,2,3,4,5,6,7,8,9,10};
		String s[] = {"Bhumur","Mukul","Pratik","Jotijai","Pranav"};
		
		ArrayPrinter.printArray(num);
		
		ArrayPrinter.printArray(s);

	}

}
