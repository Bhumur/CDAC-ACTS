package com.cdac.acts.array;

public class ArrayPrinter {
	public static void printArray(int[] arr) {
		for(int i=0;i<arr.length;i++) {
			System.out.println(arr[i]);
		}
	}
	
	public static void printArray(String[] s) {
		for(int i=0;i<s.length;i++) {
			System.out.println(s[i]);
		}
	}

}
