package com.cdac.acts.tester;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.cdac.acts.enums.PrinterTypeEnum;
import com.cdac.acts.printer.Printer;
import com.cdac.acts.util.DataEntry;

public class PrinterTest {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		Map<Integer,Printer> printers =new HashMap<>();
		String filePath = "./printer.dat";
		
		try(Scanner sc = new Scanner(System.in)){
			
			File file = new File(filePath);
			if(file.isFile()) {
				addPrinterFromFile(printers, filePath);
			}else {
				printers = DataEntry.printerMap();
				System.out.println("Take InPut From DataUtil");
			}
			int op;
			do {
					System.out.println("\nOPTIONS :- \n");
					System.out.println("1. Display All the Printers.");
					System.out.println("2. Add Printer to List.");
					System.out.println("3. Search Printer by Title.");
					System.out.println("4. Remove Printer from Map.");
					System.out.println("0. EXIT and Save PrinterMap to File.");
					System.out.print("\nEnter your choice: ");
					op = sc.nextInt();
					switch(op) {
						case 1: {
							System.out.println("Display All Printers :-");
							for(Map.Entry<Integer, Printer> p : printers.entrySet()) {
								System.out.println(p.getValue());
							}
							break;
						}
						case 2: {
							addPrinterToMap(printers, sc);
							break;
						}
						case 3: {
							System.out.println("Searching Printer by Title");
							System.out.print("Enter SerialNo of Book : ");
							Integer serialNo = sc.nextInt();
							Integer r = null;
							for(Map.Entry<Integer, Printer> p : printers.entrySet()) {
								if(p.getKey().equals(serialNo)) {
									r = p.getKey();
								}
							}
							if(r!=null) {
								System.out.println(printers.get(r));
							}
							else {
								System.out.println("NO Printer Found by SerialNo : " + serialNo);
							}
							break;
						}
						case 4: {
							System.out.println("Remove Printer by SerialNo");
							System.out.print("Enter SerialNo of Printer : ");
							Integer serialNo = sc.nextInt();
							Integer r = null;
							for(Map.Entry<Integer, Printer> p : printers.entrySet()) {
								if(p.getKey().equals(serialNo)) {
									r = p.getKey();
								}
							}
							if(r!=null) {
								System.out.println("Printer is Removed : " + printers.get(r));
								printers.remove(r);
							}
							else {
								System.out.println("NO Printer Found by SerialNo : " + serialNo);
							}
							break;
						}
						case 0: break;
						default: System.out.println("INVALID INPUT");
					}
				
			}while(op!=0);
		}
		addPrinterToFile(printers, filePath);
	}

	private static void addPrinterToMap(Map<Integer,Printer> printers, Scanner sc) {
		System.out.println("Add A Printer :- \n");
		System.out.print("Enter SerialNo of Printer : ");
		Integer serialNo = sc.nextInt();
		
		System.out.print("Enter ModalNo Of Printer : ");
		String modal = sc.next();
		System.out.print("Enter Price Of Printer : ");
		Double price = sc.nextDouble();
		System.out.print("Enter Type of Printer : ");
		String strtype = sc.next();
		PrinterTypeEnum type = PrinterTypeEnum.valueOf(strtype);
		System.out.print("Enter Manufature Date in Formate yyyy-mm-dd : ");
		String strdate = sc.next();
		LocalDate manDate = LocalDate.parse(strdate);
		
		printers.put(serialNo,new Printer(serialNo, modal, price, type, manDate));
	}

	private static void addPrinterToFile(Map<Integer,Printer> printers, String filePath) throws IOException, FileNotFoundException {
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
			for(Map.Entry<Integer, Printer> p : printers.entrySet()) {
				oos.writeObject(p.getValue());
			}
			System.out.println("Date Stored into File");
		}
	}

	private static void addPrinterFromFile(Map<Integer,Printer> printers, String filePath) throws IOException, FileNotFoundException {
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
			try{
					while(true) {
						Printer p = (Printer)ois.readObject();
						printers.put(p.getSerialNo(),p);
					}
			}catch(Exception e) {
				System.out.println("File read Complete");
			}
		}
	}

}