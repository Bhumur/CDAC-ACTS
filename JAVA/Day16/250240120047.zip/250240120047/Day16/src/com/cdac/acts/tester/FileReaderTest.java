package com.cdac.acts.tester;

import java.io.BufferedReader;

import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class FileReaderTest {

	public static void main(String[] args) throws IOException {
		try(Scanner sc = new Scanner(System.in)){
			System.out.println("Enter File Path : ");
			String path = sc.next();
			String text="";
			BufferedReader br = null;
			try {
				br = new BufferedReader(new FileReader(path)); 
			}catch (Exception e) {
				e.printStackTrace();
			}
			while((text=br.readLine())!=null) {
				System.out.println(text);
			}
		}
		

	}

}
