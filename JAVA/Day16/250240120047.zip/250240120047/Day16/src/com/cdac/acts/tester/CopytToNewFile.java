package com.cdac.acts.tester;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class CopytToNewFile {

	public static void main(String[] args) throws IOException {
		try(Scanner sc = new Scanner(System.in)){
			//System.out.println("Enter File Path of sou : ");
			String path1 = "D:/hello.txt";//sc.next();
			//System.out.println("Enter File Path of des : ");
			String path2 = "D:/cdac.txt";//sc.next();
			String text="";
			BufferedReader br = null;
			PrintWriter pw = null;
			try {
				br = new BufferedReader(new FileReader(path1)); 
			}catch (Exception e) {
				e.printStackTrace();
			}
			try {
				pw = new PrintWriter(new BufferedWriter(new FileWriter(path2,true)),true);
			}catch (Exception e) {
				e.printStackTrace();
			}
			while((text=br.readLine())!=null) {
				pw.println(text);
				System.out.println(text);
			}
			System.out.println("Finsih");
		}

	}

}
