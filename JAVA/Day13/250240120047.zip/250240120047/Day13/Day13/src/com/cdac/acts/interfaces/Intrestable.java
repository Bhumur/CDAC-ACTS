package com.cdac.acts.interfaces;

public interface Intrestable {
	void applyInterst();
}
