package com.cdac.acts.shape;

public class Shape {
	
}
