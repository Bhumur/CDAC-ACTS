package com.cdac.acts.exception;

@SuppressWarnings("serial")
public class AccountFound extends Exception {
	public AccountFound(String str) {
		super(str);
	}
}
