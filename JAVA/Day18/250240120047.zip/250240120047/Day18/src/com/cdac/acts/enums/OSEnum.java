package com.cdac.acts.enums;

public enum OSEnum {
	ANDRIOD,
	IOS;
	
	
	private OSEnum() {
		
	}
	
	
}
