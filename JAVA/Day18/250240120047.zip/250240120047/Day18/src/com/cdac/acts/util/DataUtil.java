package com.cdac.acts.util;

import java.util.ArrayList;
import java.util.List;

import com.cdac.acts.enums.OSEnum;
import com.cdac.acts.mobile.MobilePhone;

public class DataUtil {
	public static List<MobilePhone> mobileListData(){
		List<MobilePhone> list = new ArrayList<>();
		list.add(new MobilePhone("12AB","HP",OSEnum.valueOf("IOS"),"Red",124.5,8));
		list.add(new MobilePhone("21FD","NOKIA",OSEnum.valueOf("ANDRIOD"),"Pink",124.5,2));
		list.add(new MobilePhone("85SD","VIVO",OSEnum.valueOf("IOS"),"White",124.5,8));
		list.add(new MobilePhone("65WS","MOTOROLA",OSEnum.valueOf("ANDRIOD"),"Red",124.5,16));
		list.add(new MobilePhone("95FD","NOKIA",OSEnum.valueOf("IOS"),"Yellow",124.5,32));
		list.add(new MobilePhone("34DW","NOKIA",OSEnum.valueOf("ANDRIOD"),"Blue",124.5,8));
		list.add(new MobilePhone("29QW","APPLE",OSEnum.valueOf("IOS"),"Red",124.5,12));
		list.add(new MobilePhone("12QS","SAMSUNG",OSEnum.valueOf("ANDRIOD"),"Green",124.5,6));
		return list;
	}
}
