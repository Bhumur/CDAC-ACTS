package com.cdac.acts.hello;
public class HelloWorld{
	public static void main(String[] arg){
		System.out.println("Hello World");
	}
}