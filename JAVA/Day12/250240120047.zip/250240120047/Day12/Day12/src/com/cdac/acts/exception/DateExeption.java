package com.cdac.acts.exception;

@SuppressWarnings("serial")
public class DateExeption extends Exception {
	public DateExeption(String str) {
		super(str);
	}
}
