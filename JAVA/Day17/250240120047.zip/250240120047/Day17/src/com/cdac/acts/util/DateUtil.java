package com.cdac.acts.util;

import java.util.ArrayList;
import java.util.List;

import com.cdac.acts.fruit.Apple;

public class DateUtil {
	public static List<Apple> appleList(){
		List<Apple> list = new ArrayList<>();
		list.add(new Apple(78.5,"black","bitter"));
		list.add(new Apple(8.5,"black","bitter"));
		list.add(new Apple(754.5,"black","spicy"));
		list.add(new Apple(2.5,"black","salty"));
		list.add(new Apple(2.5,"black","sour"));
		list.add(new Apple(8.5,"black","sweet"));
		list.add(new Apple(15.5,"black","bitter"));
		list.add(new Apple(12.5,"black","sweet"));
		list.add(new Apple(12.5,"black","bitter"));
		list.add(new Apple(12.5,"black","bitter"));
		list.add(new Apple(17.5,"black","bitter"));
		list.add(new Apple(8.5,"pink","bitter"));
		list.add(new Apple(9.5,"red","bitter"));
		list.add(new Apple(1.0,"black","bitter"));
		return list;
	}
}
