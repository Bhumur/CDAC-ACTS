package com.cdac.acts.exception;

@SuppressWarnings("serial")
public class ElementNotFoundException extends Exception {
	public ElementNotFoundException(String s) {
		super(s);
	}
}
