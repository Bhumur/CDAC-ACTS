package com.cdac.acts.exception;

@SuppressWarnings("serial")
public class EmptyLinkedListException extends Exception{
	public EmptyLinkedListException(String s) {
		super(s);
	}
}
