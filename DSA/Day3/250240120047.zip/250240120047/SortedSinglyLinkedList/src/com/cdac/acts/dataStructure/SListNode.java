package com.cdac.acts.dataStructure;

public class SListNode {
	int data;
	SListNode next;
}
