package com.cdac.acts.exception;

@SuppressWarnings("serial")
public class ListIsEmptyException extends Exception {
	public ListIsEmptyException(String s) {
		super(s);
	}
}
