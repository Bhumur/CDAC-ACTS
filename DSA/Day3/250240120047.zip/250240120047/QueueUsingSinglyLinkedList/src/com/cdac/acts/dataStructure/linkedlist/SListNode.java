package com.cdac.acts.dataStructure.linkedlist;

public class SListNode {
	int data;
	SListNode next;
}
