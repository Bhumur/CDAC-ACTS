package com.cdac.com.dataStructure;

public class DLNode {
	int data;
	DLNode next;
	DLNode pre;
}
