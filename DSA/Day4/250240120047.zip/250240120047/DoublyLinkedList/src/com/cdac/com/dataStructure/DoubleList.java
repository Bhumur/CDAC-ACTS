package com.cdac.com.dataStructure;

public interface DoubleList extends List {
	public void printBackward();
}
