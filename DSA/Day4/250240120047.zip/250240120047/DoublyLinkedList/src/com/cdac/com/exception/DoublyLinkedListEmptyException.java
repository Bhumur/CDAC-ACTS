package com.cdac.com.exception;

@SuppressWarnings("serial")
public class DoublyLinkedListEmptyException extends Exception {
	public DoublyLinkedListEmptyException(String s) {
		super(s);
	}
}
