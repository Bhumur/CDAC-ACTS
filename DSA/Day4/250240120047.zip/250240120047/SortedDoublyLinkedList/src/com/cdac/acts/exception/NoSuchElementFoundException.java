package com.cdac.acts.exception;

@SuppressWarnings("serial")
public class NoSuchElementFoundException extends Exception{
	public NoSuchElementFoundException(String s) {
		super(s);
	}
}
