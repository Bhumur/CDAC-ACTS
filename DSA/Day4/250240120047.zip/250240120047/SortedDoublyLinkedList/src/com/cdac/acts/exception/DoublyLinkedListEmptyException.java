package com.cdac.acts.exception;

@SuppressWarnings("serial")
public class DoublyLinkedListEmptyException extends Exception {
	public DoublyLinkedListEmptyException(String s) {
		super(s);
	}
}
