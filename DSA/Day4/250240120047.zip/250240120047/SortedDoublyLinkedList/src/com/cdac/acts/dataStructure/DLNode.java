package com.cdac.acts.dataStructure;

public class DLNode {
	int data;
	DLNode next;
	DLNode pre;
}
