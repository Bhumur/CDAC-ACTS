package com.cdac.acts.exception;

@SuppressWarnings("serial")
public class StackIsEmptyException extends Exception {
	public StackIsEmptyException(String s) {
		super(s);
	}
}
