package com.cdac.acts.dataStructure.linkedList;

public class LNode {
	public int val;
	public LNode next;
	
	public LNode(int val) {
		this.val = val;
		this.next = null;
	}
}
