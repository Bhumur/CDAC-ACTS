package com.cdac.acts.exception;

@SuppressWarnings("serial")
public class TreeIsEmptyException extends Exception {
	public TreeIsEmptyException(String s) {
		super(s);
	}
}
